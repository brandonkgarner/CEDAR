# This code is used to create Ansible files for deploying Lambda's
# all that is needed is a target Lambda, tests, and it will do the rest.
# finds associate roles and policies
# creates Ansible modules based on those policies and roles
# defines the Lambdas and creates them with tests
# finds api-gateways or other events 
# if api found defines the security needed. creates modules for deployment with templates
import re
from time import sleep
import os,time, random
import shutil
from datetime import datetime, date
import boto3
from botocore.exceptions import ClientError
import  json
import sys
from shutil import copyfile
import fileinput
import logging
import urllib

import distutils
from distutils import dir_util

import awsconnect

from awsconnect import awsConnect

#from context import FormatContext
#import pyaml
#pip install pyyaml
import yaml
import decimal
#sudo ansible-playbook -i windows-servers CR-Admin-Users.yml -vvvv
dir_path = os.path.dirname(os.path.realpath(__file__))

class FormatSafeDumper(yaml.SafeDumper):
    def represent_decimal(self, data):
        return self.represent_scalar('tag:yaml.org,2002:str', str(data))
    def represent_set(self, data):
        return self.represent_sequence('tag:yaml.org,2002:seq', list(data))

FormatSafeDumper.add_representer(decimal.Decimal, FormatSafeDumper.represent_decimal)
FormatSafeDumper.add_representer(set, FormatSafeDumper.represent_set)
FormatSafeDumper.add_representer(tuple, FormatSafeDumper.represent_set)

class CommonEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o,(tuple,set)):
            return list(o)
        if isinstance(o,Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)

        if isinstance(o, datetime):
            serial = o.isoformat()
            return serial
        return super(CommonEncoder, self).default(o)

def ansibleSetup(temp, target,isFullUpdate, skipFiles=False):
    ansible_folders=["defaults","files","handlers","tasks","templates"]
    rootFolder=temp
    if not skipFiles:
        rootFolder="%s/%s"%(temp,target)
        if os.path.exists(rootFolder) and isFullUpdate:
            oldDIR = "%s_old"%rootFolder
            if os.path.exists(oldDIR):
                print ("[W] deleting old directory %s "%oldDIR)
                shutil.rmtree(oldDIR)
            os.rename(rootFolder,oldDIR)
            print (rootFolder)
        #folders needed

        if not os.path.exists(rootFolder):
            os.makedirs(rootFolder)
        for folder in ansible_folders:
            newFolder="%s/%s"%(rootFolder,folder)
            if not os.path.exists( newFolder):
                os.makedirs(newFolder)

        #CREATE Template TASkS
    targetLabel =  target.replace("-", "_")
    taskMain = [{"name": "INITIAL PROJECT SETUP  project VAR", "set_fact":{"project":"{{ %s }}"%targetLabel} },
            {"import_tasks": "../aws/sts.yml project={{ project }}"},
            {"import_tasks": "../aws/IAM.yml project={{ project }}"},
            {"import_tasks": "../aws/lambda.yml project={{ project }}"}
            #{"include": "dynamo_fixtures.yml project={{ project }}"},
     ]

    return taskMain,rootFolder,targetLabel




def writeYaml(data,filepath, option=''):
    dd = {"---":data}
    fullpath='%s%s.%s'%(filepath,option,'yaml')
    with open(fullpath, 'wb') as outfile:
        yaml.dump(dd, outfile, default_flow_style=False, encoding='utf-8', allow_unicode=True, Dumper=FormatSafeDumper)
    for line in fileinput.input([fullpath], inplace=True):
        if line.strip().startswith("'---"):
            line = '---\n'
        sys.stdout.write(line)
    return fullpath.rsplit("/",1)[1]

def writeJSON(data,filepath, option=''):
    fullpath='%s%s.%s'%(filepath,option,'js')
    with open(fullpath, 'wb') as outfile:
        json.dump(data, outfile, cls=CommonEncoder, indent=4)
    return fullpath.rsplit("/",1)[1]


def account_replace(filein, num2Search, newNumber):
    # Read in the file
    with open(filein, 'r') as file :
      filedata = file.read()

    # Replace the target string
    filedata = filedata.replace(num2Search, newNumber)

    # Write the file out again
    with open(filein, 'w') as file:
      file.write(filedata)

def loadServicesMap(fullpath,domain='RDS'):
    print (" LOADING ServiceMap: %s"%fullpath)
    if not os.path.isfile(fullpath):
        return None,None,None
    with open(fullpath, 'ru') as stream:
        exp=yaml.load(stream)
    targets=exp['services'][domain]
    return targets




def loadConfig(fullpath):
    print (" LOADING CONFIG: %s"%fullpath)
    if not os.path.isfile(fullpath):
        return None,None,None
    with open(fullpath, 'ru') as stream:
        exp=yaml.load(stream)
    target=exp['target2Define']
    global_accts = exp['accounts']
    return target, global_accts





