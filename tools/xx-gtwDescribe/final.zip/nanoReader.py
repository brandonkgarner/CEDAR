#!/usr/bin/python
import awsconnect
from microUtils import writeYaml, writeJSON, account_replace, loadServicesMap, loadConfig, ansibleSetup
#from microUtils import writeYaml, writeJSON, account_replace, loadServicesMap, loadConfig, ansibleSetup
#from microFront import CloudFrontMolder
from microGateway import ApiGatewayMolder
import logging
from datetime import datetime

import zipfile
import boto3
#from pygit import init, add, commit, push

class GwyReader():


  def __init__(self, bucket):
    self.bucket = bucket

  def zipFiles():
      pass

  def s3_send(gatewayName,files):
    s3 = aconnect.__get_client__('s3')
    now=datetime.utcnow()
    timeDir=now.strftime("%s")
    key='%s/%s'%(gatewayName, timeDir)
    for file in files:
      filename=os.path.basename(file)
      s3.upload_file(file, self.bucket, "%s/%s"%(key,filename) )
    #data = open('test.jpg', 'rb')
    #s3.Bucket('my-bucket').put_object(Key='test.jpg', Body=data)


  def s3_read(file):
      BUCKET_NAME = self.bucket # replace with your bucket name
      KEY = 'my_image_in_s3.jpg' # replace with your object key
      s3 = boto3.resource('s3')
      try:
        s3.Bucket(BUCKET_NAME).download_file(KEY, 'my_local_image.jpg')
      except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
          print("The object does not exist.")
        else:
          raise

  def sendtoGit(file1, file2):
    repoPath='/tmp/nu'
    repoPath='GatewayBackups/microUtils.py'
    init(repoPath)
    #add(['/tmp/nu/defaults_main.yaml'])
    os.chdir(repoPath)
    add(files)
    commit("time to add from lambda", author="lambdaDev")
    url="https://github.com/ClaimRuler/GatewayBackups.git"
    push(url, username=uname,password=upass)

    #github info
    # user = 'jeffdonthemic'
    # password = "secrets.password"
    # repo = 'github-pusher'
    # commitMessage = 'Code commited from AWS Lambda!'

    # repo = git.Repo("my_repository")
    # repo.git.add("bla.txt")
    # #repo.git.commit("my commit description")
    # repo.git.commit('-m', 'test commit', author='sunilt@xxx.com')
    # repo.git.pull('origin', new_branch)
    # repo.git.push('origin', new_branch)
def lambda_handler(event, context):
    # TODO implement
    main()#cr-lambda-dev
    return 'Hello from Lambda'




def main():
    start_time = time.time()
    isLambda=True
    jumpRole=False
    dir_path='/tmp'
    config='molderCONFIG.yaml'
    svc_in="ClaimRuler"
    targetAPI="ClaimRuler"
    sendto='/tmp/%s'%targetAPI

    bucket=os.environ['bucket']
    g_reader = GwyReader(bucket)

    logging.basicConfig(format='%(asctime)-15s %(message)s')
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
  
    logger.info("Started")
    print ("  ..... INIT..... 0002")

    fullpath="%s/%s"%(dir_path,config)
    origin, global_accts=loadConfig(fullpath)

    if jumpRole: 
      accountRole=global_accts[accID]['role']
      region =  origin['region']
      accID=origin['account']
      print (" ## USING ## %s--> %s, role %s, account originDefinition %s, config %s, copyAnsible to %s"%(type_in,svc_in, accountRole, accID,  config, sendto)) 
      print (" !!! !! to assume <cross_acct_role> ROLE make sure you set 'assume_role' in 'molderCONFIG.yaml' to True or False as needed")
   
      awsconnect.stsClient_init()
      sts_client = awsconnect.stsClient
      aconnect = awsConnect( accID, origin['eID'], origin['role_definer'], sts_client, region)
      aconnect.connect()
    else:
      aconnect=type('obj', (object,), { '__get_client__': boto3.client } )


    lm = ApiGatewayMolder("ansible",isLambda)
    file_tasks, file_defaults = lm.describe_GatewayALL(svc_in, aconnect, origin, global_accts,triggers, sendto, targetAPI, fullUpdate)
    #pushFiles(file_tasks, file_defaults)
    g_reader.s3_send(targetAPI,[file_tasks, file_defaults],aconnect)
    logger.info("Finished")

    print("--- %s seconds ---" % (time.time() - start_time))


if __name__ == '__main__':
    main()






